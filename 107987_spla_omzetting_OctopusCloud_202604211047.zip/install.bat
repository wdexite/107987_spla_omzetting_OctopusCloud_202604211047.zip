start C:\Fundaments\InventoryScan.exe
Schtasks /create /SC daily /ST 23:00 /TN OC_AGENT_TASK /TR "C:\Fundaments\InventoryScan.exe" /RU "NT AUTHORITY\SYSTEM"